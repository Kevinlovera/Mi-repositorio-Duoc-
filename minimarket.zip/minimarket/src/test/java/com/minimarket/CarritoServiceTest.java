package com.minimarket;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import org.mockito.junit.jupiter.MockitoExtension;

import com.minimarket.entity.Carrito;
import com.minimarket.entity.Producto;
import com.minimarket.repository.CarritoRepository;
import com.minimarket.service.impl.CarritoServiceImpl;

@ExtendWith(MockitoExtension.class)
class CarritoServiceTest {

    @Mock
    private CarritoRepository carritoRepository;

    @InjectMocks
    private CarritoServiceImpl carritoService;

    @Test
    void agregarProductoConStockSuficiente() {

        Producto producto = new Producto();
        producto.setStock(10);

        Carrito carrito = new Carrito();
        carrito.setProducto(producto);
        carrito.setCantidad(3);

        boolean resultado =
                carritoService.agregarProducto(carrito);

        assertTrue(resultado);

        assertEquals(
                7,
                producto.getStock()
        );

        verify(carritoRepository)
                .save(carrito);
    }

    @Test
    void agregarProductoSinStock() {

        Producto producto = new Producto();
        producto.setStock(2);

        Carrito carrito = new Carrito();
        carrito.setProducto(producto);
        carrito.setCantidad(5);

        boolean resultado =
                carritoService.agregarProducto(carrito);

        assertFalse(resultado);

        verify(carritoRepository, never())
                .save(any());
    }

    @Test
void agregarProductoSinProducto() {

    Carrito carrito = new Carrito();

    carrito.setCantidad(2);

    boolean resultado =
            carritoService.agregarProducto(carrito);

    assertFalse(resultado);

    verify(carritoRepository,
            never())
            .save(any());
}
@Test
void agregarProductoCantidadNula() {

    Producto producto = new Producto();

    producto.setStock(10);

    Carrito carrito = new Carrito();

    carrito.setProducto(producto);

    boolean resultado =
            carritoService.agregarProducto(carrito);

    assertFalse(resultado);

    verify(carritoRepository,
            never())
            .save(any());
}
@Test
void agregarProductoStockExacto() {

    Producto producto = new Producto();
    producto.setStock(5);

    Carrito carrito = new Carrito();
    carrito.setProducto(producto);
    carrito.setCantidad(5);

    boolean resultado =
            carritoService.agregarProducto(carrito);

    assertTrue(resultado);

    assertEquals(
            0,
            producto.getStock()
    );

    verify(carritoRepository)
            .save(carrito);
}
}