package com.minimarket;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;

import com.minimarket.entity.Inventario;
import com.minimarket.entity.Producto;

class InventarioTest {

    @Test
    void productoAsociadoCorrectamente() {

        Producto producto = new Producto();

        Inventario inventario = new Inventario();

        inventario.setProducto(producto);

        assertEquals(
                producto,
                inventario.getProducto()
        );
    }

    @Test
    void cantidadCorrecta() {

        Inventario inventario = new Inventario();

        inventario.setCantidad(20);

        assertEquals(
                20,
                inventario.getCantidad()
        );
    }

    @Test
    void tipoMovimientoCorrecto() {

        Inventario inventario = new Inventario();

        inventario.setTipoMovimiento("ENTRADA");

        assertEquals(
                "ENTRADA",
                inventario.getTipoMovimiento()
        );
    }

    @Test
    void tipoMovimientoNoNulo() {

        Inventario inventario = new Inventario();

        inventario.setTipoMovimiento("SALIDA");

        assertNotNull(
                inventario.getTipoMovimiento()
        );
    }
}