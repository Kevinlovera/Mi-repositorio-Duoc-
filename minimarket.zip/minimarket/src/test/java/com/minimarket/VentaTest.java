package com.minimarket;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

import com.minimarket.entity.DetalleVenta;
import com.minimarket.entity.Usuario;
import com.minimarket.entity.Venta;

class VentaTest {

    @Test
    void usuarioAsociadoCorrectamente() {

        Usuario usuario = new Usuario();

        Venta venta = new Venta();

        venta.setUsuario(usuario);

        assertEquals(
                usuario,
                venta.getUsuario()
        );
    }

    @Test
    void fechaCorrecta() {

        Date fecha = new Date();

        Venta venta = new Venta();

        venta.setFecha(fecha);

        assertEquals(
                fecha,
                venta.getFecha()
        );
    }

    @Test
    void detallesAsociadosCorrectamente() {

        Venta venta = new Venta();

        List<DetalleVenta> detalles =
                new ArrayList<>();

        detalles.add(new DetalleVenta());

        venta.setDetalles(detalles);

        assertEquals(
                1,
                venta.getDetalles().size()
        );

    }}