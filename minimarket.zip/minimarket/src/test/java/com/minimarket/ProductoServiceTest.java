package com.minimarket;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;

import com.minimarket.entity.Producto;
import com.minimarket.repository.ProductoRepository;
import com.minimarket.service.impl.ProductoServiceImpl;

@ExtendWith(MockitoExtension.class)
class ProductoServiceTest {

    @Mock
    private ProductoRepository productoRepository;

    @InjectMocks
    private ProductoServiceImpl productoService;

    @Test
    void guardarProducto() {

        Producto producto = new Producto();
        producto.setNombre("Leche");

        when(productoRepository.save(producto))
                .thenReturn(producto);

        Producto resultado =
                productoService.save(producto);

        assertNotNull(resultado);

        assertEquals(
                "Leche",
                resultado.getNombre()
        );

        verify(productoRepository)
                .save(producto);
    }

    @Test
    void buscarTodosLosProductos() {

        Producto producto = new Producto();

        when(productoRepository.findAll())
                .thenReturn(List.of(producto));

        List<Producto> productos =
                productoService.findAll();

        assertEquals(
                1,
                productos.size()
        );

        verify(productoRepository)
                .findAll();
    }

    @Test
    void eliminarProducto() {

        productoService.deleteById(1L);

        verify(productoRepository)
                .deleteById(1L);
    }
}