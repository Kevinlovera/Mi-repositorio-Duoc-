package com.minimarket;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;

import com.minimarket.entity.Categoria;
import com.minimarket.entity.Producto;

class ProductoTest {

    @Test
    void nombreProductoCorrecto() {

        Producto producto = new Producto();

        producto.setNombre("Leche");

        assertEquals(
                "Leche",
                producto.getNombre()
        );
    }

    @Test
    void stockCorrecto() {

        Producto producto = new Producto();

        producto.setStock(50);

        assertEquals(
                50,
                producto.getStock()
        );
    }

    @Test
    void precioCorrecto() {

        Producto producto = new Producto();

        producto.setPrecio(1500.0);

        assertEquals(
                1500.0,
                producto.getPrecio()
        );
    }

    @Test
    void categoriaAsociadaCorrectamente() {

        Categoria categoria = new Categoria();

        Producto producto = new Producto();

        producto.setCategoria(categoria);

        assertEquals(
                categoria,
                producto.getCategoria()
        );
    }

    @Test
    void stockNoNulo() {

        Producto producto = new Producto();

        producto.setStock(10);

        assertNotNull(
                producto.getStock()
        );
    }
}