package com.minimarket;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;

import com.minimarket.entity.Categoria;
import com.minimarket.repository.CategoriaRepository;
import com.minimarket.service.impl.CategoriaServiceImpl;

@ExtendWith(MockitoExtension.class)
class CategoriaServiceTest {

    @Mock
    private CategoriaRepository categoriaRepository;

    @InjectMocks
    private CategoriaServiceImpl categoriaService;

    @Test
    void guardarCategoria() {

        Categoria categoria = new Categoria();
        categoria.setNombre("Lacteos");

        when(categoriaRepository.save(categoria))
                .thenReturn(categoria);

        Categoria resultado =
                categoriaService.save(categoria);

        assertNotNull(resultado);

        assertEquals(
                "Lacteos",
                resultado.getNombre()
        );

        verify(categoriaRepository)
                .save(categoria);
    }

    @Test
    void listarCategorias() {

        Categoria categoria =
                new Categoria();

        when(categoriaRepository.findAll())
                .thenReturn(List.of(categoria));

        List<Categoria> categorias =
                categoriaService.findAll();

        assertEquals(
                1,
                categorias.size()
        );

        verify(categoriaRepository)
                .findAll();
    }

    @Test
    void eliminarCategoria() {

        categoriaService.deleteById(1L);

        verify(categoriaRepository)
                .deleteById(1L);
    }

}