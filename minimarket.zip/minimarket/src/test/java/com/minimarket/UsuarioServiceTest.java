package com.minimarket;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.junit.jupiter.MockitoExtension;

import com.minimarket.entity.Usuario;
import com.minimarket.repository.UsuarioRepository;
import com.minimarket.service.impl.UsuarioServiceImpl;

@ExtendWith(MockitoExtension.class)
class UsuarioServiceTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @InjectMocks
    private UsuarioServiceImpl usuarioService;

    @Test
    void guardarUsuario() {

        Usuario usuario = new Usuario();
        usuario.setUsername("kevin");

        when(usuarioRepository.save(usuario))
                .thenReturn(usuario);

        Usuario resultado =
                usuarioService.save(usuario);

        assertNotNull(resultado);

        assertEquals(
                "kevin",
                resultado.getUsername()
        );

        verify(usuarioRepository)
                .save(usuario);
    }

    @Test
    void listarUsuarios() {

        Usuario usuario = new Usuario();

        when(usuarioRepository.findAll())
                .thenReturn(List.of(usuario));

        List<Usuario> usuarios =
                usuarioService.findAll();

        assertEquals(
                1,
                usuarios.size()
        );

        verify(usuarioRepository)
                .findAll();
    }

    @Test
    void buscarPorId() {

        Usuario usuario = new Usuario();

        when(usuarioRepository.findById(1L))
                .thenReturn(Optional.of(usuario));

        Optional<Usuario> resultado =
                usuarioService.findById(1L);

        assertTrue(resultado.isPresent());

        verify(usuarioRepository)
                .findById(1L);
    }

    @Test
    void buscarPorUsername() {

        Usuario usuario = new Usuario();
        usuario.setUsername("kevin");

        when(usuarioRepository.findByUsername("kevin"))
                .thenReturn(Optional.of(usuario));

        Optional<Usuario> resultado =
                usuarioService.findByUsername("kevin");

        assertTrue(resultado.isPresent());

        verify(usuarioRepository)
                .findByUsername("kevin");
    }

    @Test
    void eliminarUsuario() {

        usuarioService.deleteById(1L);

        verify(usuarioRepository)
                .deleteById(1L);
    }
    @Test
void buscarUsuarioPorIdNoExiste() {

    when(usuarioRepository.findById(99L))
            .thenReturn(Optional.empty());

    Optional<Usuario> resultado =
            usuarioService.findById(99L);

    assertFalse(resultado.isPresent());

    verify(usuarioRepository)
            .findById(99L);
}
@Test
void buscarUsernameNoExiste() {

    when(usuarioRepository.findByUsername("fantasma"))
            .thenReturn(Optional.empty());

    Optional<Usuario> resultado =
            usuarioService.findByUsername("fantasma");

    assertFalse(resultado.isPresent());

    verify(usuarioRepository)
            .findByUsername("fantasma");
}
}