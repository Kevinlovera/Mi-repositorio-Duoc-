package com.minimarket;

import com.minimarket.entity.DetalleVenta;
import com.minimarket.repository.DetalleVentaRepository;
import com.minimarket.service.impl.DetalleVentaServiceImpl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DetalleVentaServiceTest {

    @Mock
    private DetalleVentaRepository detalleVentaRepository;

    @InjectMocks
    private DetalleVentaServiceImpl detalleVentaService;

    @Test
    void guardarDetalleVenta() {

        DetalleVenta detalle = new DetalleVenta();

        when(detalleVentaRepository.save(detalle))
                .thenReturn(detalle);

        DetalleVenta resultado =
                detalleVentaService.save(detalle);

        assertNotNull(resultado);

        verify(detalleVentaRepository)
                .save(detalle);
    }

    @Test
    void listarDetalleVentas() {

        DetalleVenta detalle = new DetalleVenta();

        when(detalleVentaRepository.findAll())
                .thenReturn(List.of(detalle));

        List<DetalleVenta> lista =
                detalleVentaService.findAll();

        assertEquals(1, lista.size());

        verify(detalleVentaRepository)
                .findAll();
    }

    @Test
    void buscarDetallePorId() {

        DetalleVenta detalle = new DetalleVenta();

        when(detalleVentaRepository.findById(1L))
                .thenReturn(Optional.of(detalle));

        DetalleVenta resultado =
                detalleVentaService.findById(1L);

        assertNotNull(resultado);

        verify(detalleVentaRepository)
                .findById(1L);
    }

    @Test
    void buscarDetallePorIdNoExiste() {

        when(detalleVentaRepository.findById(99L))
                .thenReturn(Optional.empty());

        DetalleVenta resultado =
                detalleVentaService.findById(99L);

        assertNull(resultado);

        verify(detalleVentaRepository)
                .findById(99L);
    }

    @Test
    void eliminarDetalleVenta() {

        detalleVentaService.deleteById(1L);

        verify(detalleVentaRepository)
                .deleteById(1L);
    }

    @Test
    void buscarPorVentaId() {

        DetalleVenta detalle = new DetalleVenta();

        when(detalleVentaRepository.findByVentaId(1L))
                .thenReturn(List.of(detalle));

        List<DetalleVenta> lista =
                detalleVentaService.findByVentaId(1L);

        assertEquals(1, lista.size());

        verify(detalleVentaRepository)
                .findByVentaId(1L);
    }
}