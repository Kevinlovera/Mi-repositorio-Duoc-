package com.minimarket;

import com.minimarket.entity.Categoria;
import com.minimarket.entity.Producto;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CategoriaTest {

    @Test
    void nombreCategoriaCorrecto() {

        Categoria categoria = new Categoria();

        categoria.setNombre("Lacteos");

        assertEquals(
                "Lacteos",
                categoria.getNombre()
        );
    }

    @Test
    void listaProductosCorrecta() {

        Categoria categoria = new Categoria();

        List<Producto> productos =
                new ArrayList<>();

        productos.add(new Producto());

        categoria.setProductos(productos);

        assertEquals(
                1,
                categoria.getProductos().size()
        );
    }

    @Test
    void productosNoNulos() {

        Categoria categoria = new Categoria();

        categoria.setProductos(
                new ArrayList<>()
        );

        assertNotNull(
                categoria.getProductos()
        );
    }
}