package com.minimarket;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

import com.minimarket.entity.DetalleVenta;
import com.minimarket.entity.Producto;
import com.minimarket.entity.Venta;

class DetalleVentaTest {

    @Test
    void ventaAsociadaCorrectamente() {

        Venta venta = new Venta();

        DetalleVenta detalle =
                new DetalleVenta();

        detalle.setVenta(venta);

        assertEquals(
                venta,
                detalle.getVenta()
        );
    }

    @Test
    void productoAsociadoCorrectamente() {

        Producto producto =
                new Producto();

        DetalleVenta detalle =
                new DetalleVenta();

        detalle.setProducto(producto);

        assertEquals(
                producto,
                detalle.getProducto()
        );
    }

    @Test
    void cantidadCorrecta() {

        DetalleVenta detalle =
                new DetalleVenta();

        detalle.setCantidad(5);

        assertEquals(
                5,
                detalle.getCantidad()
        );
    }

    @Test
    void precioCorrecto() {

        DetalleVenta detalle =
                new DetalleVenta();

        detalle.setPrecio(2500.0);

        assertEquals(
                2500.0,
                detalle.getPrecio()
        );
    }
}