package com.minimarket;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

import com.minimarket.entity.Carrito;
import com.minimarket.entity.Producto;
import com.minimarket.entity.Usuario;

class CarritoTest {

    @Test
    void usuarioAsociadoCorrectamente() {

        Usuario usuario = new Usuario();

        Carrito carrito = new Carrito();

        carrito.setUsuario(usuario);

        assertEquals(
                usuario,
                carrito.getUsuario()
        );
    }

    @Test
    void productoAsociadoCorrectamente() {

        Producto producto = new Producto();

        Carrito carrito = new Carrito();

        carrito.setProducto(producto);

        assertEquals(
                producto,
                carrito.getProducto()
        );
    }

    @Test
    void cantidadCorrecta() {

        Carrito carrito = new Carrito();

        carrito.setCantidad(5);

        assertEquals(
                5,
                carrito.getCantidad()
        );
    }
    @Test
void idCorrecto() {

    Carrito carrito = new Carrito();

    carrito.setId(1L);

    assertEquals(
            1L,
            carrito.getId()
    );
}

}