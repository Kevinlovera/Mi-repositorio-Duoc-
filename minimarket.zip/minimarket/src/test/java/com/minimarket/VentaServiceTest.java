package com.minimarket;

import com.minimarket.entity.Venta;
import com.minimarket.repository.VentaRepository;
import com.minimarket.service.impl.VentaServiceImpl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VentaServiceTest {

    @Mock
    private VentaRepository ventaRepository;

    @InjectMocks
    private VentaServiceImpl ventaService;

    @Test
    void guardarVenta() {

        Venta venta = new Venta();

        when(ventaRepository.save(venta))
                .thenReturn(venta);

        Venta resultado =
                ventaService.save(venta);

        assertNotNull(resultado);

        verify(ventaRepository)
                .save(venta);
    }

    @Test
    void listarVentas() {

        Venta venta = new Venta();

        when(ventaRepository.findAll())
                .thenReturn(List.of(venta));

        List<Venta> ventas =
                ventaService.findAll();

        assertEquals(1, ventas.size());

        verify(ventaRepository)
                .findAll();
    }

    @Test
    void buscarPorUsuario() {

        Venta venta = new Venta();

        when(ventaRepository.findByUsuarioId(1L))
                .thenReturn(List.of(venta));

        List<Venta> ventas =
                ventaService.findByUsuarioId(1L);

        assertEquals(1, ventas.size());

        verify(ventaRepository)
                .findByUsuarioId(1L);
    }

    @Test
    void buscarVentaPorId() {

        Venta venta = new Venta();

        when(ventaRepository.findById(1L))
                .thenReturn(Optional.of(venta));

        Venta resultado =
                ventaService.findById(1L);

        assertNotNull(resultado);

        verify(ventaRepository)
                .findById(1L);
    }

    @Test
    void buscarVentaPorIdNoExiste() {

        when(ventaRepository.findById(99L))
                .thenReturn(Optional.empty());

        Venta resultado =
                ventaService.findById(99L);

        assertNull(resultado);

        verify(ventaRepository)
                .findById(99L);
    }
}