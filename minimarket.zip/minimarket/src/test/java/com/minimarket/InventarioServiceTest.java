package com.minimarket;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import org.mockito.junit.jupiter.MockitoExtension;

import com.minimarket.entity.Inventario;
import com.minimarket.entity.Producto;
import com.minimarket.repository.InventarioRepository;
import com.minimarket.service.impl.InventarioServiceImpl;

@ExtendWith(MockitoExtension.class)
class InventarioServiceTest {

    @Mock
    private InventarioRepository inventarioRepository;

    @InjectMocks
    private InventarioServiceImpl inventarioService;

    @Test
    void registrarMovimientoValido() {

        Producto producto = new Producto();

        Inventario inventario = new Inventario();
        inventario.setProducto(producto);
        inventario.setCantidad(10);
        inventario.setTipoMovimiento("ENTRADA");

        boolean resultado =
                inventarioService.registrarMovimiento(inventario);

        assertTrue(resultado);

        verify(inventarioRepository).save(inventario);
    }

    @Test
    void registrarMovimientoSinProducto() {

        Inventario inventario = new Inventario();
        inventario.setCantidad(10);
        inventario.setTipoMovimiento("ENTRADA");

        boolean resultado =
                inventarioService.registrarMovimiento(inventario);

        assertFalse(resultado);

        verify(inventarioRepository, never())
                .save(any());
    }

    @Test
    void registrarMovimientoCantidadCero() {

        Producto producto = new Producto();

        Inventario inventario = new Inventario();
        inventario.setProducto(producto);
        inventario.setCantidad(0);
        inventario.setTipoMovimiento("ENTRADA");

        boolean resultado =
                inventarioService.registrarMovimiento(inventario);

        assertFalse(resultado);

        verify(inventarioRepository, never())
                .save(any());
    }

    @Test
    void registrarMovimientoSinTipoMovimiento() {

        Producto producto = new Producto();

        Inventario inventario = new Inventario();
        inventario.setProducto(producto);
        inventario.setCantidad(10);
        inventario.setTipoMovimiento("");

        boolean resultado =
                inventarioService.registrarMovimiento(inventario);

        assertFalse(resultado);

        verify(inventarioRepository, never())
                .save(any());
    }
    @Test
void registrarMovimientoCantidadNula() {

    Producto producto = new Producto();

    Inventario inventario =
            new Inventario();

    inventario.setProducto(producto);

    inventario.setTipoMovimiento("ENTRADA");

    boolean resultado =
            inventarioService
                    .registrarMovimiento(inventario);

    assertFalse(resultado);

    verify(inventarioRepository,
            never())
            .save(any());
}
@Test
void registrarMovimientoTipoNulo() {

    Producto producto =
            new Producto();

    Inventario inventario =
            new Inventario();

    inventario.setProducto(producto);

    inventario.setCantidad(10);

    boolean resultado =
            inventarioService
                    .registrarMovimiento(inventario);

    assertFalse(resultado);

    verify(inventarioRepository,
            never())
            .save(any());
}
@Test
void registrarMovimientoCantidadNegativa() {

    Inventario inventario =
            new Inventario();

    inventario.setCantidad(-5);

    boolean resultado =
            inventarioService.registrarMovimiento(inventario);

    assertFalse(resultado);
}
@Test
void registrarMovimientoTipoVacio() {

    Inventario inventario =
            new Inventario();

    Producto producto =
            new Producto();

    inventario.setProducto(producto);
    inventario.setCantidad(5);
    inventario.setTipoMovimiento("");

    boolean resultado =
            inventarioService.registrarMovimiento(inventario);

    assertFalse(resultado);
}
}