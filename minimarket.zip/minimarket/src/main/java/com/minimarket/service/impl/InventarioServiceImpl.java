package com.minimarket.service.impl;

import com.minimarket.entity.Inventario;
import com.minimarket.repository.InventarioRepository;
import com.minimarket.service.InventarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventarioServiceImpl implements InventarioService {

    @Autowired
    private InventarioRepository inventarioRepository;

    @Override
    public List<Inventario> findAll() {
        return inventarioRepository.findAll();
    }

    @Override
    public Inventario findById(Long id) {
        return inventarioRepository.findById(id).orElse(null);
    }

    @Override
    public Inventario save(Inventario inventario) {
        return inventarioRepository.save(inventario);
    }

    @Override
    public void deleteById(Long id) {
        inventarioRepository.deleteById(id);
    }

    @Override
    public List<Inventario> findByProductoId(Long productoId) {
        return inventarioRepository.findByProductoId(productoId);
    }

    @Override
    public boolean registrarMovimiento(Inventario inventario) {

        if (inventario == null) {
            return false;
        }

        if (inventario.getProducto() == null) {
            return false;
        }

        if (inventario.getCantidad() == null) {
            return false;
        }

        if (inventario.getCantidad() <= 0) {
            return false;
        }

        if (inventario.getTipoMovimiento() == null
                || inventario.getTipoMovimiento().isBlank()) {
            return false;
        }

        inventarioRepository.save(inventario);

        return true;
    }
}
