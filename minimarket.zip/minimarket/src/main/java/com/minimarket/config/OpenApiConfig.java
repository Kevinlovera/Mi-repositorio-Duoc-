package com.minimarket.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

     @Bean
    public OpenAPI minimarketOpenAPI() {

        return new OpenAPI()
                .info(new Info()
                        .title("API Minimarket Plus")
                        .description("API REST desarrollada con Spring Boot para la gestión de productos, usuarios, ventas, inventario, categorías y carritos del sistema Minimarket Plus.")
                        .version("1.0.0")
                        .contact(new Contact()
                                .name("Kevin Jesús")
                                .email("kevinjesus@gmail.com"))
                        .license(new License()
                                .name("Uso Académico")));
    }

}
