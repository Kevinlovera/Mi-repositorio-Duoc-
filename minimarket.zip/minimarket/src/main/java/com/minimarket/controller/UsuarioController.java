package com.minimarket.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.minimarket.entity.Usuario;
import com.minimarket.service.UsuarioService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;


@Tag(
        name = "Usuarios",
        description = "Operaciones relacionadas con la administración de usuarios."
)
@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;



       @Operation(
        summary = "Listar usuarios",
        description = "Obtiene todos los usuarios registrados."
)
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Usuarios obtenidos correctamente"),
        @ApiResponse(responseCode = "500", description = "Error interno")
})
 

    @GetMapping
public CollectionModel<EntityModel<Usuario>> listarUsuarios() {

    List<EntityModel<Usuario>> usuarios = usuarioService.findAll()
            .stream()
            .map(usuario -> EntityModel.of(
                    usuario,
                    linkTo(methodOn(UsuarioController.class)
                            .obtenerUsuarioPorId(usuario.getId()))
                            .withSelfRel()))
            .collect(Collectors.toList());

    return CollectionModel.of(
            usuarios,
            linkTo(methodOn(UsuarioController.class)
                    .listarUsuarios())
                    .withSelfRel());
}


    @Operation(
        summary = "Buscar usuario",
        description = "Obtiene un usuario mediante su ID."
)

    /* 
    @GetMapping("/{id}")
    public ResponseEntity<Usuario> obtenerUsuarioPorId(@PathVariable Long id) {
        Optional<Usuario> usuario = usuarioService.findById(id);
        return usuario.map(ResponseEntity::ok) // Si el usuario existe, devuelve 200 OK con el usuario
                .orElseGet(() -> ResponseEntity.notFound().build()); // Si no, devuelve 404
    }*/

                @GetMapping("/{id}")
public ResponseEntity<EntityModel<Usuario>> obtenerUsuarioPorId(@PathVariable Long id) {

    Optional<Usuario> usuario = usuarioService.findById(id);

    if (usuario.isEmpty()) {
        return ResponseEntity.notFound().build();
    }

    EntityModel<Usuario> usuarioModel = EntityModel.of(usuario.get());

    usuarioModel.add(
            linkTo(methodOn(UsuarioController.class)
                    .obtenerUsuarioPorId(id))
                    .withSelfRel());

    usuarioModel.add(
            linkTo(methodOn(UsuarioController.class)
                    .listarUsuarios())
                    .withRel("todos-los-usuarios"));

    return ResponseEntity.ok(usuarioModel);
}

    @Operation(
        summary = "Registrar usuario",
        description = "Registra un nuevo usuario."
)
    @PostMapping
    public Usuario guardarUsuario(@RequestBody Usuario usuario) {
        return usuarioService.save(usuario);
    }

    @Operation(
        summary = "Actualizar usuario",
        description = "Actualiza la información de un usuario."
)
    @PutMapping("/{id}")
    public ResponseEntity<Usuario> actualizarUsuario(@PathVariable Long id, @RequestBody Usuario usuario) {
        Optional<Usuario> usuarioExistente = usuarioService.findById(id);
        if (usuarioExistente.isPresent()) {
            usuario.setId(id);
            return ResponseEntity.ok(usuarioService.save(usuario));
        }
        return ResponseEntity.notFound().build();
    }


    @Operation(
        summary = "Eliminar usuario",
        description = "Elimina un usuario del sistema."
)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarUsuario(@PathVariable Long id) {
        Optional<Usuario> usuario = usuarioService.findById(id);
        if (usuario.isPresent()) { // Verifica si el usuario existe
            usuarioService.deleteById(id); // Elimina al usuario
            return ResponseEntity.noContent().build(); // Respuesta 204 (sin contenido)
        }
        return ResponseEntity.notFound().build(); // Respuesta 404 (no encontrado)
    }
}
