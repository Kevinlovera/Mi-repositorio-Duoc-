package com.minimarket.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.minimarket.entity.Carrito;
import com.minimarket.service.CarritoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;


@Tag(
        name = "Carrito",
        description = "Operaciones relacionadas con la gestión del carrito de compras."
)
@RestController
@RequestMapping("/api/carrito")
public class CarritoController {

    @Autowired
    private CarritoService carritoService;


    @Operation(
        summary = "Listar carrito",
        description = "Obtiene todos los productos agregados al carrito."
)
@ApiResponses({
        @ApiResponse(responseCode = "200", description = "Carrito obtenido correctamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
})

/* 
    @GetMapping
    public List<Carrito> listarCarrito() {
        return carritoService.findAll();
    }
*/
    @GetMapping
        public CollectionModel<EntityModel<Carrito>> listarCarrito(){

            List<EntityModel<Carrito>> carritos = carritoService.findAll()
            .stream()
            .map(carrito -> EntityModel.of(carrito,linkTo(methodOn(CarritoController.class)
        .obtenerCarritoPorId(carrito.getId()))
    .withSelfRel()))
    .collect(Collectors.toList());

    return CollectionModel.of(carritos, linkTo(methodOn(CarritoController.class)
.listarCarrito())
.withSelfRel());
        }

    @Operation(
        summary = "Buscar producto del carrito",
        description = "Obtiene un elemento del carrito mediante su ID."
)
@ApiResponses({
        @ApiResponse(responseCode = "200", description = "Elemento encontrado"),
        @ApiResponse(responseCode = "404", description = "Elemento no encontrado")
})

/* 
    @GetMapping("/{id}")
    public ResponseEntity<Carrito> obtenerCarritoPorId(@PathVariable Long id) {
        Carrito carrito = carritoService.findById(id);
        return (carrito != null) ? ResponseEntity.ok(carrito) : ResponseEntity.notFound().build();
    }
*/

@GetMapping("/{id}")
        public ResponseEntity<EntityModel<Carrito>> obtenerCarritoPorId(@PathVariable Long id) {

            Carrito carrito = carritoService.findById(id);

            if (carrito == null) {
                return ResponseEntity.notFound().build();
            }

            EntityModel<Carrito> carritoModel = EntityModel.of(carrito);

            carritoModel.add(
                linkTo(methodOn(CarritoController.class)
            .obtenerCarritoPorId(id))
            .withSelfRel());

            carritoModel.add(
                linkTo(methodOn(ProductoController.class)
            .listarProductos())
            .withRel("Todos los productos")
            );

            return ResponseEntity.ok(carritoModel);
        }
    @Operation(
        summary = "Agregar producto al carrito",
        description = "Agrega un producto al carrito de compras."
)
@ApiResponses({
        @ApiResponse(responseCode = "200", description = "Producto agregado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos")
})
    @PostMapping
    public Carrito agregarProductoAlCarrito(@RequestBody Carrito carrito) {
        return carritoService.save(carrito);
    }


    @Operation(
        summary = "Actualizar carrito",
        description = "Actualiza la cantidad o información de un producto del carrito."
)
@ApiResponses({
        @ApiResponse(responseCode = "200", description = "Carrito actualizado"),
        @ApiResponse(responseCode = "404", description = "Elemento no encontrado")
})
    @PutMapping("/{id}")
    public ResponseEntity<Carrito> actualizarCarrito(@PathVariable Long id, @RequestBody Carrito carrito) {
        Carrito existente = carritoService.findById(id);
        if (existente != null) {
            carrito.setId(id);
            return ResponseEntity.ok(carritoService.save(carrito));
        }
        return ResponseEntity.notFound().build();
    }

    @Operation(
        summary = "Eliminar producto del carrito",
        description = "Elimina un producto del carrito utilizando su ID."
)
@ApiResponses({
        @ApiResponse(responseCode = "204", description = "Producto eliminado correctamente"),
        @ApiResponse(responseCode = "404", description = "Elemento no encontrado")
})
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarProductoDelCarrito(@PathVariable Long id) {
        Carrito carrito = carritoService.findById(id);
        if (carrito != null) {
            carritoService.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
