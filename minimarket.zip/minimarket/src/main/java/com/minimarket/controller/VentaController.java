package com.minimarket.controller;

import com.minimarket.entity.Venta;
import com.minimarket.service.VentaService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(
        name = "Ventas",
        description = "Operaciones relacionadas con las ventas del minimarket."
)
@RestController
@RequestMapping("/api/ventas")
public class VentaController {

    @Autowired
    private VentaService ventaService;

       @Operation(
        summary = "Listar ventas",
        description = "Obtiene todas las ventas registradas.")

    @GetMapping
    public List<Venta> listarVentas() {
        return ventaService.findAll();
    }

 
    @Operation(
        summary = "Buscar venta",
        description = "Obtiene una venta mediante su ID."
)

    @GetMapping("/{id}")
    public ResponseEntity<Venta> obtenerVentaPorId(@PathVariable Long id) {
        Venta venta = ventaService.findById(id);
        return (venta != null) ? ResponseEntity.ok(venta) : ResponseEntity.notFound().build();
    }

  @Operation(
        summary = "Registrar venta",
        description = "Registra una nueva venta."
)
    @PostMapping
    public Venta guardarVenta(@RequestBody Venta venta) {
        return ventaService.save(venta);
    }
}
