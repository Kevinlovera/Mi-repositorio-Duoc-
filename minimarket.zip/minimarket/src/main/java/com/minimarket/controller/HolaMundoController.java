package com.minimarket.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(
        name = "Pruebas",
        description = "Endpoints públicos de prueba."
)
@RestController
public class HolaMundoController {

 
    @Operation(
        summary = "Hola Mundo",
        description = "Endpoint público para verificar que la API se encuentra funcionando."
)
    @GetMapping("/public/hola")
    public String holaMundo() {
        return "¡Hola Mundo!";
    }
}
