package com.minimarket.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.minimarket.entity.Inventario;
import com.minimarket.service.InventarioService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(
        name = "Inventario",
        description = "Operaciones relacionadas con el control del inventario."
)
@RestController
@RequestMapping("/api/inventario")
public class InventarioController {

    @Autowired
    private InventarioService inventarioService;

    @Operation(
        summary = "Listar movimientos",
        description = "Obtiene todos los movimientos de inventario."
)

   @GetMapping
public CollectionModel<EntityModel<Inventario>> listarMovimientosDeInventario() {

    List<EntityModel<Inventario>> inventarios = inventarioService.findAll()
            .stream()
            .map(inventario -> EntityModel.of(
                    inventario,
                    linkTo(methodOn(InventarioController.class)
                            .obtenerMovimientoPorId(inventario.getId()))
                            .withSelfRel()))
            .collect(Collectors.toList());

    return CollectionModel.of(
            inventarios,
            linkTo(methodOn(InventarioController.class)
                    .listarMovimientosDeInventario())
                    .withSelfRel());
}

    @Operation(
        summary = "Buscar movimiento",
        description = "Obtiene un movimiento de inventario mediante su ID."
)
@GetMapping("/{id}")
public ResponseEntity<EntityModel<Inventario>> obtenerMovimientoPorId(@PathVariable Long id) {

    Inventario inventario = inventarioService.findById(id);

    if (inventario == null) {
        return ResponseEntity.notFound().build();
    }

    EntityModel<Inventario> inventarioModel = EntityModel.of(inventario);

    inventarioModel.add(
            linkTo(methodOn(InventarioController.class)
                    .obtenerMovimientoPorId(id))
                    .withSelfRel());

    inventarioModel.add(
            linkTo(methodOn(InventarioController.class)
                    .listarMovimientosDeInventario())
                    .withRel("todos-los-movimientos"));

    return ResponseEntity.ok(inventarioModel);
}

    @Operation(
        summary = "Registrar movimiento",
        description = "Registra un nuevo movimiento de inventario."
)
    @PostMapping
    public Inventario registrarMovimiento(@RequestBody Inventario inventario) {
        return inventarioService.save(inventario);
    }

    @Operation(
        summary = "Actualizar movimiento",
        description = "Actualiza un movimiento de inventario."
)
    @PutMapping("/{id}")
    public ResponseEntity<Inventario> actualizarMovimiento(@PathVariable Long id, @RequestBody Inventario inventario) {
        Inventario existente = inventarioService.findById(id);
        if (existente != null) {
            inventario.setId(id);
            return ResponseEntity.ok(inventarioService.save(inventario));
        }
        return ResponseEntity.notFound().build();
    }

    @Operation(
        summary = "Eliminar movimiento",
        description = "Elimina un movimiento de inventario."
)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarMovimiento(@PathVariable Long id) {
        Inventario inventario = inventarioService.findById(id);
        if (inventario != null) {
            inventarioService.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
