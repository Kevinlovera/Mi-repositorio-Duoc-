package com.minimarket.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import  org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.minimarket.entity.Producto;
import com.minimarket.service.ProductoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;


@Tag(
        name = "Productos",
        description = "Operaciones para la administración de productos del minimarket."
)
@RestController
@RequestMapping("/api/productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @Operation(
        summary = "Listar productos",
        description = "Obtiene la lista completa de productos registrados."
)
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista obtenida correctamente"),
        @ApiResponse(responseCode = "500", description = "Error interno del servidor")
})

    /* 
    @GetMapping
    public List<Producto> listarProductos() {
        return productoService.findAll();
    }*/


        @GetMapping
        public CollectionModel<EntityModel<Producto>> listarProductos(){

            List<EntityModel<Producto>> productos = productoService.findAll()
            .stream()
            .map(producto -> EntityModel.of(producto,linkTo(methodOn(ProductoController.class)
        .obtenerProductoPorId(producto.getId()))
    .withSelfRel()))
    .collect(Collectors.toList());

    return CollectionModel.of(productos, linkTo(methodOn(ProductoController.class)
.listarProductos())
.withSelfRel());
        }


    @Operation(
        summary = "Buscar producto por ID",
        description = "Obtiene un producto utilizando su identificador."
)
@ApiResponses({
        @ApiResponse(responseCode = "200", description = "Producto encontrado"),
        @ApiResponse(responseCode = "404", description = "Producto no encontrado")
})

    /*@GetMapping("/{id}")
    public ResponseEntity<Producto> obtenerProductoPorId(@PathVariable Long id) {
        Producto producto = productoService.findById(id);
        return (producto != null) ? ResponseEntity.ok(producto) : ResponseEntity.notFound().build();

        Este era mi metodo antiguo, lo he cambiado
    }   */

        @GetMapping("/{id}")
        public ResponseEntity<EntityModel<Producto>> obtenerProductoPorId(@PathVariable Long id) {

            Producto producto = productoService.findById(id);

            if (producto == null) {
                return ResponseEntity.notFound().build();
            }

            EntityModel<Producto> productoModel = EntityModel.of(producto);

            productoModel.add(
                linkTo(methodOn(ProductoController.class)
            .obtenerProductoPorId(id))
            .withSelfRel());

            productoModel.add(
                linkTo(methodOn(ProductoController.class)
            .listarProductos())
            .withRel("Todos los productos")
            );

            return ResponseEntity.ok(productoModel);
        }

    @Operation(
        summary = "Crear producto",
        description = "Registra un nuevo producto en el sistema."
)
@ApiResponses({
        @ApiResponse(responseCode = "200", description = "Producto creado correctamente"),
        @ApiResponse(responseCode = "400", description = "Datos inválidos")
})
    @PostMapping
    public Producto guardarProducto(@RequestBody Producto producto) {
        return productoService.save(producto);
    }


    @Operation(
        summary = "Actualizar producto",
        description = "Actualiza la información de un producto existente."
)
@ApiResponses({
        @ApiResponse(responseCode = "200", description = "Producto actualizado"),
        @ApiResponse(responseCode = "404", description = "Producto no encontrado")
})
    @PutMapping("/{id}")
    public ResponseEntity<Producto> actualizarProducto(@PathVariable Long id, @RequestBody Producto producto) {
        Producto productoExistente = productoService.findById(id);
        if (productoExistente != null) {
            producto.setId(id);
            return ResponseEntity.ok(productoService.save(producto));
        }
        return ResponseEntity.notFound().build();
    }

    @Operation(
        summary = "Eliminar un producto",
        description = "Eliminar un producto existente."
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Producto eliminado"),
        @ApiResponse(responseCode = "404", description = "producto no encontrado")
    })

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarProducto(@PathVariable Long id) {
        Producto producto = productoService.findById(id);
        if (producto != null) {
            productoService.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
