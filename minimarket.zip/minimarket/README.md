# Minimarket Plus

Sistema backend desarrollado con Spring Boot para la gestión de un minimarket.

## Tecnologías utilizadas

- Spring Boot 3
- Spring Security
- Spring Data JPA
- OpenAPI (Swagger)
- Spring HATEOAS
- Base de datos H2

## Cómo ejecutar el proyecto

1. Clonar el repositorio.
2. Abrir el proyecto en Visual Studio Code o IntelliJ IDEA.
3. Ejecutar la clase `MinimarketApplication`.

## Documentación Swagger

http://localhost:8091/swagger-ui/index.html

## OpenAPI JSON

http://localhost:8091/v3/api-docs