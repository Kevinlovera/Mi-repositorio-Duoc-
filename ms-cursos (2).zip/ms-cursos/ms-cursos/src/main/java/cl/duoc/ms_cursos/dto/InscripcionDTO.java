package cl.duoc.ms_cursos.dto;

import java.util.List;

public class InscripcionDTO {

    private String nombreEstudiante;

    private List<Long> cursosIds;

    public InscripcionDTO() {
    }

    public String getNombreEstudiante() {
        return nombreEstudiante;
    }

    public void setNombreEstudiante(String nombreEstudiante) {
        this.nombreEstudiante = nombreEstudiante;
    }

    public List<Long> getCursosIds() {
        return cursosIds;
    }

    public void setCursosIds(List<Long> cursosIds) {
        this.cursosIds = cursosIds;
    }
}