package cl.duoc.ms_cursos.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duoc.ms_cursos.entity.Curso;
import cl.duoc.ms_cursos.repository.CursoRepository;

@Service
public class CursoService {

    @Autowired
    private CursoRepository cursoRepository;

    public List<Curso> obtenerTodos() {
        return cursoRepository.findAll();
    }

    public Optional<Curso> obtenerPorId(Long id) {
        return cursoRepository.findById(id);
    }

    public Curso guardar(Curso curso) {
        return cursoRepository.save(curso);
    }

    public Curso actualizar(Long id, Curso cursoActualizado) {

        Optional<Curso> cursoExistente = cursoRepository.findById(id);

        if (cursoExistente.isPresent()) {

            Curso curso = cursoExistente.get();

            curso.setNombre(cursoActualizado.getNombre());
            curso.setInstructor(cursoActualizado.getInstructor());
            curso.setDuracionHoras(cursoActualizado.getDuracionHoras());
            curso.setCosto(cursoActualizado.getCosto());

            return cursoRepository.save(curso);
        }

        return null;
    }

    public void eliminar(Long id) {
        cursoRepository.deleteById(id);
    }
}