package cl.duoc.ms_cursos.service;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class ResumenService {

    public ResponseEntity<Resource> descargarResumen(Long id) {

        try {

            Path ruta = Paths.get("resumenes")
                    .resolve("Resumen_" + id + ".txt")
                    .toAbsolutePath();

            Resource recurso = new UrlResource(ruta.toUri());

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=Resumen_" + id + ".txt")
                    .body(recurso);

        } catch (Exception e) {

            return ResponseEntity.notFound().build();
        }
    }

    public String eliminarResumen(Long id) {

        try {

            Path ruta = Paths.get("resumenes")
                    .resolve("Resumen_" + id + ".txt")
                    .toAbsolutePath();

            File archivo = ruta.toFile();

            if (archivo.exists()) {

                archivo.delete();

                return "Resumen eliminado correctamente";
            }

            return "Resumen no encontrado";

        } catch (Exception e) {

            return "Error al eliminar";
        }
    }

    public String modificarResumen(
            Long id,
            String contenido) {

        try {

            Path ruta = Paths.get("resumenes")
                    .resolve("Resumen_" + id + ".txt")
                    .toAbsolutePath();

            FileWriter writer =
                    new FileWriter(ruta.toFile());

            writer.write(contenido);

            writer.close();

            return "Resumen actualizado correctamente";

        } catch (Exception e) {

            return "Error al actualizar";
        }
    }
}