package cl.duoc.ms_cursos.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.duoc.ms_cursos.entity.Curso;


@Repository
public interface CursoRepository extends JpaRepository <Curso, Long> {

}
