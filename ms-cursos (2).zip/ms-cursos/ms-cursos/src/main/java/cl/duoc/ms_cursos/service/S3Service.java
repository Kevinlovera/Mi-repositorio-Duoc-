package cl.duoc.ms_cursos.service;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import org.springframework.stereotype.Service;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

@Service
public class S3Service {

    private final String bucketName =
            "ms-cursos-resumenes-kevin-alexander2026";

    private final S3Client s3Client;

    public S3Service() {

        this.s3Client = S3Client.builder()
                .region(Region.US_EAST_1)
                .build();
    }

    public String subirResumen(Long id) {

        try {

            String key =
                    id + "/Resumen_" + id + ".txt";

            s3Client.putObject(
                    PutObjectRequest.builder()
                            .bucket(bucketName)
                            .key(key)
                            .build(),
                    Paths.get(
                            "resumenes",
                            "Resumen_" + id + ".txt"));

            return "Resumen subido correctamente";

        } catch (Exception e) {

            return "Error: " + e.getMessage();
        }
    }

    public String descargarResumen(Long id) {

        try {

            String key =
                    id + "/Resumen_" + id + ".txt";

            s3Client.getObject(
                    GetObjectRequest.builder()
                            .bucket(bucketName)
                            .key(key)
                            .build(),
                    Paths.get(
                            "resumenes",
                            "Descargado_" + id + ".txt"));

            return "Resumen descargado";

        } catch (Exception e) {

            return "Error: " + e.getMessage();
        }
    }

    public String actualizarResumen(
            Long id,
            String contenido) {

        try {

            Files.writeString(
                    Paths.get(
                            "resumenes",
                            "Resumen_" + id + ".txt"),
                    contenido,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);

            return subirResumen(id);

        } catch (Exception e) {

            return "Error: " + e.getMessage();
        }
    }

    public String eliminarResumen(Long id) {

        try {

            String key =
                    id + "/Resumen_" + id + ".txt";

            s3Client.deleteObject(
                    DeleteObjectRequest.builder()
                            .bucket(bucketName)
                            .key(key)
                            .build());

            return "Resumen eliminado";

        } catch (Exception e) {

            return "Error: " + e.getMessage();
        }
    }
}
