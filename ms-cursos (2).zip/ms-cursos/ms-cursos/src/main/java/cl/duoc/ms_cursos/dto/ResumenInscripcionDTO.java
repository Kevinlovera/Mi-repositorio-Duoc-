package cl.duoc.ms_cursos.dto;

import java.util.List;

public class ResumenInscripcionDTO {

    private String nombreEstudiante;

    private List<String> cursos;

    private Double totalPagar;

    public ResumenInscripcionDTO() {
    }

    public String getNombreEstudiante() {
        return nombreEstudiante;
    }

    public void setNombreEstudiante(String nombreEstudiante) {
        this.nombreEstudiante = nombreEstudiante;
    }

    public List<String> getCursos() {
        return cursos;
    }

    public void setCursos(List<String> cursos) {
        this.cursos = cursos;
    }

    public Double getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(Double totalPagar) {
        this.totalPagar = totalPagar;
    }
}
