package cl.duoc.ms_cursos.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duoc.ms_cursos.dto.InscripcionDTO;
import cl.duoc.ms_cursos.dto.ResumenInscripcionDTO;
import cl.duoc.ms_cursos.entity.Inscripcion;
import cl.duoc.ms_cursos.service.InscripcionService;

@RestController
@RequestMapping("/inscripciones")
public class InscripcionController {

    @Autowired
    private InscripcionService inscripcionService;

    @PostMapping
    public ResumenInscripcionDTO inscribir(
            @RequestBody InscripcionDTO dto) {

        return inscripcionService.inscribir(dto);
    }

    @GetMapping
    public List<Inscripcion> obtenerTodas() {

        return inscripcionService.obtenerTodas();
    }

    @GetMapping("/{id}")
public Inscripcion obtenerPorId(@PathVariable Long id) {
    return inscripcionService.obtenerPorId(id);
}

@DeleteMapping("/{id}")
public String eliminar(@PathVariable Long id) {

    inscripcionService.eliminar(id);

    return "Inscripción eliminada correctamente";
}
}