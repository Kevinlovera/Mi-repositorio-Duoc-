package cl.duoc.ms_cursos.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duoc.ms_cursos.dto.InscripcionDTO;
import cl.duoc.ms_cursos.dto.ResumenInscripcionDTO;
import cl.duoc.ms_cursos.entity.Curso;
import cl.duoc.ms_cursos.entity.Inscripcion;
import cl.duoc.ms_cursos.repository.CursoRepository;
import cl.duoc.ms_cursos.repository.InscripcionRepository;

@Service
public class InscripcionService {

    @Autowired
    private InscripcionRepository inscripcionRepository;

    @Autowired
    private CursoRepository cursoRepository;

    public ResumenInscripcionDTO inscribir(InscripcionDTO dto) {

        List<String> nombresCursos = new ArrayList<>();

        double total = 0;

        for (Long idCurso : dto.getCursosIds()) {

            Curso curso = cursoRepository.findById(idCurso).orElse(null);

            if (curso != null) {

                nombresCursos.add(curso.getNombre());

                total += curso.getCosto();
            }
        }

        Inscripcion inscripcion = new Inscripcion();

        inscripcion.setNombreEstudiante(dto.getNombreEstudiante());

        inscripcion.setTotalPagar(total);

        inscripcionRepository.save(inscripcion);

        ResumenInscripcionDTO resumen = new ResumenInscripcionDTO();

        resumen.setNombreEstudiante(dto.getNombreEstudiante());

        resumen.setCursos(nombresCursos);

        resumen.setTotalPagar(total);

        return resumen;
    }

    public Inscripcion obtenerPorId(Long id) {
    return inscripcionRepository.findById(id).orElse(null);
}

public void eliminar(Long id) {
    inscripcionRepository.deleteById(id);
}

    public List<Inscripcion> obtenerTodas() {
        return inscripcionRepository.findAll();
    }
}
