 package cl.duoc.ms_cursos.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duoc.ms_cursos.service.ResumenService;
import cl.duoc.ms_cursos.service.S3Service;

@RestController
@RequestMapping("/resumenes")
public class ResumenController {

    @Autowired
    private ResumenService resumenService;

    @Autowired
    private S3Service s3Service;

    // DESCARGAR RESUMEN LOCAL
    @GetMapping("/{id}")
    public ResponseEntity<Resource> descargarResumen(
            @PathVariable Long id) {

        return resumenService.descargarResumen(id);
    }

    // ELIMINAR RESUMEN LOCAL
    @DeleteMapping("/{id}")
    public String eliminarResumen(
            @PathVariable Long id) {

        return resumenService.eliminarResumen(id);
    }

    // MODIFICAR RESUMEN LOCAL
    @PutMapping("/{id}")
    public String modificarResumen(
            @PathVariable Long id,
            @RequestBody String contenido) {

        return resumenService.modificarResumen(
                id,
                contenido);
    }

    // SUBIR A S3
    @PostMapping("/upload/{id}")
    public String subirAS3(
            @PathVariable Long id) {

        return s3Service.subirResumen(id);
    }

    // DESCARGAR DESDE S3
    @GetMapping("/download-s3/{id}")
    public String descargarDesdeS3(
            @PathVariable Long id) {

        return s3Service.descargarResumen(id);
    }

    // ACTUALIZAR EN S3
    @PutMapping("/update-s3/{id}")
    public String actualizarEnS3(
            @PathVariable Long id,
            @RequestBody String contenido) {

        return s3Service.actualizarResumen(
                id,
                contenido);
    }

    // ELIMINAR DE S3
    @DeleteMapping("/delete-s3/{id}")
    public String eliminarDeS3(
            @PathVariable Long id) {

        return s3Service.eliminarResumen(id);
    }
}