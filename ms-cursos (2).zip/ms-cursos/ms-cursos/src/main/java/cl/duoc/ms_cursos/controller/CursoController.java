package cl.duoc.ms_cursos.controller;

import cl.duoc.ms_cursos.entity.Curso;
import cl.duoc.ms_cursos.service.CursoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/cursos")
public class CursoController {

    @Autowired
    private CursoService cursoService;

    @GetMapping
    public List<Curso> obtenerCursos() {

        return cursoService.obtenerTodos();
    }

    @GetMapping("/{id}")
    public Optional<Curso> obtenerCursoPorId(
            @PathVariable Long id) {

        return cursoService.obtenerPorId(id);
    }

    @PostMapping
    public Curso guardarCurso(
            @RequestBody Curso curso) {

        return cursoService.guardar(curso);
    }

    @PutMapping("/{id}")
    public Curso actualizarCurso(
            @PathVariable Long id,
            @RequestBody Curso curso) {

        return cursoService.actualizar(id, curso);
    }

    @DeleteMapping("/{id}")
    public String eliminarCurso(
            @PathVariable Long id) {

        cursoService.eliminar(id);

        return "Curso eliminado correctamente";
    }
}