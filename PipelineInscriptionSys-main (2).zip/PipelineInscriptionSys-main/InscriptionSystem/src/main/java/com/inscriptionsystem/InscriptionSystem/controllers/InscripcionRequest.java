package com.inscriptionsystem.InscriptionSystem.controllers;

import java.util.List;

public class InscripcionRequest {
    
    private Long estudianteId;
    private List<Long> cursoIds;
    
    public InscripcionRequest() {
    }
    
    public InscripcionRequest(Long estudianteId, List<Long> cursoIds) {
        this.estudianteId = estudianteId;
        this.cursoIds = cursoIds;
    }
    
    public Long getEstudianteId() {
        return estudianteId;
    }
    
    public void setEstudianteId(Long estudianteId) {
        this.estudianteId = estudianteId;
    }
    
    public List<Long> getCursoIds() {
        return cursoIds;
    }
    
    public void setCursoIds(List<Long> cursoIds) {
        this.cursoIds = cursoIds;
    }
}
