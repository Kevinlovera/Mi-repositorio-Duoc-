package com.inscriptionsystem.InscriptionSystem.services;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

@Service
public class S3Service {

    @Autowired
    private S3Client s3Client;

    private final String bucketName = "inscripcion-s2-2026";

    public void subirArchivo(File archivo) {

        PutObjectRequest request =
                PutObjectRequest.builder()
                .bucket(bucketName)
                .key(archivo.getName())
                .build();

        s3Client.putObject(
                request,
                archivo.toPath());

        System.out.println(
                "Archivo subido a S3 correctamente");
    }
}