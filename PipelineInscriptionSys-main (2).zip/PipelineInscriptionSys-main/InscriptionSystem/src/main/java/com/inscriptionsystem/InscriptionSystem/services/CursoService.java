package com.inscriptionsystem.InscriptionSystem.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.inscriptionsystem.InscriptionSystem.entity.Curso;
import com.inscriptionsystem.InscriptionSystem.entity.Instructor;
import com.inscriptionsystem.InscriptionSystem.repository.CursoRepository;
import com.inscriptionsystem.InscriptionSystem.repository.InstructorRepository;

@Service
public class CursoService {

    @Autowired
    private CursoRepository cursoRepository;
    
    @Autowired
    private InstructorRepository instructorRepository;

    public Curso saveCurso(Curso curso) {
        // Si viene instructorId, buscar el instructor
        if (curso.getInstructorId() != null) {
            Instructor instructor = instructorRepository.findById(curso.getInstructorId()).orElse(null);
            curso.setInstructor(instructor);
        }
        return cursoRepository.save(curso);
    }   

    public List<Curso> getAllCursos(){
        return cursoRepository.findAll();
    }

}
