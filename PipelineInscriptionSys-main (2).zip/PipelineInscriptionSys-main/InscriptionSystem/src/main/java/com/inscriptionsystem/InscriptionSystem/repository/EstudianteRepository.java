package com.inscriptionsystem.InscriptionSystem.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.inscriptionsystem.InscriptionSystem.entity.Estudiante;

@Repository
public interface EstudianteRepository extends JpaRepository<Estudiante, Long> {

    Estudiante findByNumRut(String numRut);
    Estudiante findByNombre(String nombre);

}
