package com.inscriptionsystem.InscriptionSystem.services;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inscriptionsystem.InscriptionSystem.entity.Curso;
import com.inscriptionsystem.InscriptionSystem.entity.Inscripcion;

@Service
public class ResumenService {

    @Autowired
    private S3Service s3Service;

    public void generarResumen(Inscripcion inscripcion) {

        try {

            String rutaProyecto = System.getProperty("user.dir");

            File carpeta = new File(rutaProyecto + "\\resumenes");

            if (!carpeta.exists()) {
                carpeta.mkdirs();
            }

            String nombreArchivo =
                    carpeta.getAbsolutePath()
                    + "\\resumen_"
                    + inscripcion.getId()
                    + ".txt";

            System.out.println("Creando archivo en:");
            System.out.println(nombreArchivo);

            FileWriter writer = new FileWriter(nombreArchivo);

            writer.write("=================================\n");
            writer.write("RESUMEN DE INSCRIPCION\n");
            writer.write("=================================\n\n");

            writer.write("ID: " + inscripcion.getId() + "\n\n");

            writer.write("ESTUDIANTE\n");
            writer.write(
                    inscripcion.getEstudiante().getNombre()
                    + " "
                    + inscripcion.getEstudiante().getApellidoPaterno()
                    + "\n");

            writer.write(
                    "RUT: "
                    + inscripcion.getEstudiante().getNumRut()
                    + "\n\n");

            writer.write("CURSOS\n");

            for (Curso curso : inscripcion.getCursos()) {
                writer.write("- " + curso.getNombre() + "\n");
            }

            writer.write("\nTOTAL A PAGAR\n");
            writer.write("$" + inscripcion.getTotalAPagar() + "\n\n");

            writer.write("FECHA\n");
            writer.write(
                    inscripcion.getFechaInscripcion().toString());

            writer.close();

            File archivoGenerado =
                    new File(nombreArchivo);

            s3Service.subirArchivo(archivoGenerado);

            System.out.println("RESUMEN GENERADO CORRECTAMENTE");

        } catch (IOException e) {

            System.out.println("ERROR AL CREAR EL ARCHIVO");
            e.printStackTrace();
        }
    }
}