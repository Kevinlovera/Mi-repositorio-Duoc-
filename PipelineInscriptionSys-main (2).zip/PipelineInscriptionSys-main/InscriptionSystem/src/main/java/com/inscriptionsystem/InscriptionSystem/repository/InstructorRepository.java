package com.inscriptionsystem.InscriptionSystem.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.inscriptionsystem.InscriptionSystem.entity.Instructor;

@Repository
public interface InstructorRepository extends JpaRepository<Instructor, Long> {

    Instructor findByNumRut(String numRut);
    Instructor findByNombre(String nombre);
}
