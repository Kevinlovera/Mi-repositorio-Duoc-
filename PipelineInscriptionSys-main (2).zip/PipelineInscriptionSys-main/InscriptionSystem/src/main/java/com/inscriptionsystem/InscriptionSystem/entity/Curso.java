package com.inscriptionsystem.InscriptionSystem.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Transient;

@Entity
public class Curso {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String nombre;
    
    @ManyToOne
    private Instructor instructor;
    
    private double duracion;
    private int precio;
    
    @Transient
    private Long instructorId;

    public Curso() {
    }

    public Curso(String nombre, Instructor instructor, double duracion, int precio) {
        this.nombre = nombre;
        this.instructor = instructor;
        this.duracion = duracion;
        this.precio = precio;
    }

    public Long getId() {
        return id;
    }

    public Long getInstructorId() {
        return instructorId;
    }

    public void setInstructorId(Long instructorId) {
        this.instructorId = instructorId;
    }

    public String getNombre() {
        return nombre;
    }

    public Instructor getInstructor() {
        return instructor;
    }

    public void setInstructor(Instructor instructor) {
        this.instructor = instructor;
    }

    public double getDuracion() {
        return duracion;
    }

    public int getPrecio() {
        return precio;
    }

}
