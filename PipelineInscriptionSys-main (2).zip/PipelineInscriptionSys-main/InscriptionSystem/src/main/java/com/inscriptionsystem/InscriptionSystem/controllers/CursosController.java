package com.inscriptionsystem.InscriptionSystem.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.inscriptionsystem.InscriptionSystem.entity.Curso;
import com.inscriptionsystem.InscriptionSystem.services.CursoService;

@RestController
public class CursosController {
    
    @Autowired
    private CursoService cursoService;
    
    @GetMapping("/cursos")
    public List<Curso> getAllCursos() {
        return cursoService.getAllCursos();
    }

    @PostMapping("/cursos")
    public Curso saveCurso(@RequestBody Curso curso) {
        return cursoService.saveCurso(curso);
    }
}
