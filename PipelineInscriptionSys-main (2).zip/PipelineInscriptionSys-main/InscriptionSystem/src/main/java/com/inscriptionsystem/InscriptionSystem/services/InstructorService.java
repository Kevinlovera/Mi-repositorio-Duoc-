package com.inscriptionsystem.InscriptionSystem.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inscriptionsystem.InscriptionSystem.entity.Instructor;
import com.inscriptionsystem.InscriptionSystem.repository.InstructorRepository;

@Service
public class InstructorService {
    @Autowired
    InstructorRepository instructorRepository;
    
    public List<Instructor> getAllInstructors() {
        return instructorRepository.findAll();
    }
    
    public Instructor getInstructorByNumRut(String numRut) {
        return instructorRepository.findByNumRut(numRut);
    }

    public Instructor getInstructorByNombre(String nombre) {
        return instructorRepository.findByNombre(nombre);
    }

    public Instructor saveInstructor(Instructor instructor) {
        return instructorRepository.save(instructor);
    }

    public void deleteInstructor(Long id) {
        instructorRepository.deleteById(id);
    }
}
