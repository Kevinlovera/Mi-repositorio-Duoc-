package com.inscriptionsystem.InscriptionSystem.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.inscriptionsystem.InscriptionSystem.entity.Instructor;
import com.inscriptionsystem.InscriptionSystem.services.InstructorService;


@RestController
public class InstructorController {
    @Autowired
    private InstructorService instructorService;

    @GetMapping("/instructor/{numRut}")
    public Instructor getInstructor(@PathVariable String numRut) {
        return instructorService.getInstructorByNumRut(numRut);
    }

    @GetMapping("/instructors")
    public List<Instructor> getAllInstructors() {
        return instructorService.getAllInstructors();
    }

    @PostMapping("/instructors")
    public Instructor saveInstructor(@RequestBody Instructor instructor) {
        return instructorService.saveInstructor(instructor);
    }

    @DeleteMapping("/instructors/{id}")
    public void deleteInstructor(@PathVariable Long id) {
        instructorService.deleteInstructor(id);
    }



}
