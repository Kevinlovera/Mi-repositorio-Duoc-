package com.inscriptionsystem.InscriptionSystem.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.inscriptionsystem.InscriptionSystem.entity.Inscripcion;
import com.inscriptionsystem.InscriptionSystem.services.InscripcionService;

@RestController
public class InscripcionController {
    
    @Autowired
    private InscripcionService inscripcionService;
    
    @PostMapping("/inscripciones")
    public Inscripcion crearInscripcion(@RequestBody InscripcionRequest request) {
        return inscripcionService.crearInscripcion(request.getEstudianteId(), request.getCursoIds());
    }
    
    @GetMapping("/inscripciones/{id}")
    public Inscripcion obtenerInscripcion(@PathVariable Long id) {
        return inscripcionService.obtenerInscripcion(id);
    }
    
    @GetMapping("/estudiantes/{estudianteId}/inscripciones")
    public List<Inscripcion> obtenerInscripcionesPorEstudiante(@PathVariable Long estudianteId) {
        return inscripcionService.obtenerInscripcionesPorEstudiante(estudianteId);
    }
}
