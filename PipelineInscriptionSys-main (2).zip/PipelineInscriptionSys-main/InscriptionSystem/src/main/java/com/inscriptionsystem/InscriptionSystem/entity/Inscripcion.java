package com.inscriptionsystem.InscriptionSystem.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.JoinTable;
import jakarta.persistence.JoinColumn;
import java.time.LocalDateTime;
import java.util.List;

@Entity
public class Inscripcion {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @ManyToOne
    private Estudiante estudiante;
    
    @ManyToMany
    @JoinTable(
        name = "inscripcion_curso",
        joinColumns = @JoinColumn(name = "inscripcion_id"),
        inverseJoinColumns = @JoinColumn(name = "curso_id")
    )
    private List<Curso> cursos;
    
    private LocalDateTime fechaInscripcion;
    private double totalAPagar;
    
    public Inscripcion() {
    }
    
    public Inscripcion(Estudiante estudiante, List<Curso> cursos) {
        this.estudiante = estudiante;
        this.cursos = cursos;
        this.fechaInscripcion = LocalDateTime.now();
        this.totalAPagar = calcularTotal();
    }
    
    private double calcularTotal() {
        return cursos.stream()
            .mapToDouble(Curso::getPrecio)
            .sum();
    }
    
    public Long getId() {
        return id;
    }
    
    public Estudiante getEstudiante() {
        return estudiante;
    }
    
    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }
    
    public List<Curso> getCursos() {
        return cursos;
    }
    
    public void setCursos(List<Curso> cursos) {
        this.cursos = cursos;
        this.totalAPagar = calcularTotal();
    }
    
    public LocalDateTime getFechaInscripcion() {
        return fechaInscripcion;
    }
    
    public void setFechaInscripcion(LocalDateTime fechaInscripcion) {
        this.fechaInscripcion = fechaInscripcion;
    }
    
    public double getTotalAPagar() {
        return totalAPagar;
    }
    
    public void setTotalAPagar(double totalAPagar) {
        this.totalAPagar = totalAPagar;
    }
}
