package com.inscriptionsystem.InscriptionSystem.controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class ArchivoController {

} 

