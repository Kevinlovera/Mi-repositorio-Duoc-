package com.inscriptionsystem.InscriptionSystem.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inscriptionsystem.InscriptionSystem.entity.Curso;
import com.inscriptionsystem.InscriptionSystem.entity.Estudiante;
import com.inscriptionsystem.InscriptionSystem.entity.Inscripcion;
import com.inscriptionsystem.InscriptionSystem.repository.CursoRepository;
import com.inscriptionsystem.InscriptionSystem.repository.EstudianteRepository;
import com.inscriptionsystem.InscriptionSystem.repository.InscripcionRepository;

@Service
public class InscripcionService {

    @Autowired
    private ResumenService resumenService;

    @Autowired
    private InscripcionRepository inscripcionRepository;

    @Autowired
    private EstudianteRepository estudianteRepository;

    @Autowired
    private CursoRepository cursoRepository;

    public Inscripcion crearInscripcion(Long estudianteId, List<Long> cursoIds) {

        Estudiante estudiante = estudianteRepository.findById(estudianteId)
                .orElseThrow(() -> new RuntimeException("Estudiante no encontrado"));

        List<Curso> cursos = cursoRepository.findAllById(cursoIds);

        if (cursos.isEmpty()) {
            throw new RuntimeException("Debe seleccionar al menos un curso");
        }

        Inscripcion inscripcion = new Inscripcion(estudiante, cursos);

        Inscripcion inscripcionGuardada =
                inscripcionRepository.save(inscripcion);

        resumenService.generarResumen(inscripcionGuardada);

        return inscripcionGuardada;
    }

    public Inscripcion obtenerInscripcion(Long id) {
        return inscripcionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Inscripción no encontrada"));
    }

    public List<Inscripcion> obtenerInscripcionesPorEstudiante(Long estudianteId) {
        return inscripcionRepository.findByEstudianteId(estudianteId);
    }
}