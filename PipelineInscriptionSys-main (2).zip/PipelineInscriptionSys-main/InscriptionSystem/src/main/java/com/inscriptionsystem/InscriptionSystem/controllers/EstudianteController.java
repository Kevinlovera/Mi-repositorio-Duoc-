package com.inscriptionsystem.InscriptionSystem.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.inscriptionsystem.InscriptionSystem.entity.Estudiante;
import com.inscriptionsystem.InscriptionSystem.services.EstudianteService;

@RestController
public class EstudianteController {
    
    @Autowired
    private EstudianteService estudianteService;
    
    @PostMapping("/estudiantes")
    public Estudiante crearEstudiante(@RequestBody Estudiante estudiante) {
        return estudianteService.crearEstudiante(estudiante);
    }
    
    @GetMapping("/estudiantes")
    public List<Estudiante> obtenerTodos() {
        return estudianteService.obtenerTodos();
    }
    
    @GetMapping("/estudiantes/{id}")
    public Estudiante obtenerPorId(@PathVariable Long id) {
        return estudianteService.obtenerPorId(id);
    }
    
    @GetMapping("/estudiantes/numRut/{numRut}")
    public Estudiante obtenerPorNumRut(@PathVariable String numRut) {
        return estudianteService.obtenerPorNumRut(numRut);
    }
}
