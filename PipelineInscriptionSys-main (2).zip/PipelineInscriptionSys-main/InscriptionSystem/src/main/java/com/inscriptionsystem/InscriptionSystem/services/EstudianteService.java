package com.inscriptionsystem.InscriptionSystem.services;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.inscriptionsystem.InscriptionSystem.entity.Estudiante;
import com.inscriptionsystem.InscriptionSystem.repository.EstudianteRepository;

@Service
public class EstudianteService {

    @Autowired
    private EstudianteRepository estudianteRepository;
    
    public Estudiante crearEstudiante(Estudiante estudiante) {
        return estudianteRepository.save(estudiante);
    }
    
    public List<Estudiante> obtenerTodos() {
        return estudianteRepository.findAll();
    }
    
    public Estudiante obtenerPorId(Long id) {
        return estudianteRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Estudiante no encontrado"));
    }
    
    public Estudiante obtenerPorNumRut(String numRut) {
        return estudianteRepository.findByNumRut(numRut);
    }
}
