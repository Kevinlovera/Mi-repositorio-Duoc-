package com.inscriptionsystem.InscriptionSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InscriptionSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(InscriptionSystemApplication.class, args);
		
	}

}
