package com.inscriptionsystem.InscriptionSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InscriptionSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
